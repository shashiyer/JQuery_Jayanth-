$(function() {
  // jQuery goes here... 
  
  $(".lightbox").delay(500).fadeIn(1000);
  
  
/*
  $(".red-box").fadeOut(2000);
  $(".green-box").delay(2000).fadeOut(2000);
  $(".blue-box").delay(4000).fadeOut(2000);
  
  */
  
 /*
 $(".blue-box").animate( 
  {
	  "margin-left":"500px",
	  "width":"20px",
	  "height":"20px",
	  "opacity":"0",
	  "margin-top":"50px"
	    },4000,"swing"
  );
 */
 
 
/* 
  $(".blue-box").animate( 
  {
	  "margin-left":"200px"
  },5000,"swing"
  );
  */
  //$("p").hide(4000);
  //$("p").show(4000);
  
  //$(".red-box").hide(4000);
  //$(".red-box").show(4000);
  
  
  //$(".red-box").slideUp(4000);
  //$(".red-box").slideDown(4000);
  
  
  //$(".red-box").fadeOut(4000);
  //$(".red-box").fadeTo(4000,0);
  
  //$(".red-box").fadeToggle(4000);
//  $(".red-box").fadeToggle(4000);
  
  
//  $(".red-box").fadeTo(3000,0.7);
  
  
  //$(".red-box").fadeOut(4000);
  //$(".green-box").fadeOut(4000);
  //$(".red-box").fadeIn(4000);
  
});