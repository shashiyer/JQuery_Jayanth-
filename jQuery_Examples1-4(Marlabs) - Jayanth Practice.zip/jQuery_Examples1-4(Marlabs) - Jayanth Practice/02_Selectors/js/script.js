$(function () {
	
$("p:odd").css("background-color","rgba(180,180,30,.8)")	
//$("p:odd").css("background-color","rgba(180,180,30,.8)")	
//$("p:even").css("background-color","rgba(180,180,30,.8)")	
//$("p:first").css("background-color","rgba(180,180,30,.8)")	
//$("p:last").css("background-color","rgba(180,180,30,.8)")	


//$("h1,p,input").css("background-color","rgba(180,180,30,.8)")	


//$("input[type='password']").css("background-color","rgba(180,180,30,.8)")	
//$("input[type='text']").css("background-color","rgba(180,180,30,.8)")	
//$("input").css("background-color","rgba(180,180,30,.8)")	


//$("#list").css("background-color","rgba(180,180,30,.8)")	


//$(".red-box").css("background-color","rgba(180,180,30,.8)")	
	
 //$("p").css("background-color","red");
// $("p").css("background-color","rgba(180,180,30,.8)");
});