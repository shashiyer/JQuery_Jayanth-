$(function () {

 //   $("#list").prev().prev().css("background-color","rgba(18,180,120,0.7)");
//$("#list").prev().css("background-color","rgba(180,180,30,0.4)");

//$("#list").next().css("background-color","rgba(180,180,30,0.4)");

//$("p").siblings().css("background-color","rgba(180,180,30,0.4)");

// $("#list").siblings().css("background-color","rgba(180,180,30,0.4)");

//$("li").parent("ul").css("background-color","rgba(180,180,30,0.4)");


//$("#list").parents("div").css("background-color","green");



$("#list").parents().css("font-size","30px");



//$("#list").children("li").css("background-color","rgba(180,180,30,0.4)");
 
 
// $("#list").find("li").css("background-color","rgba(120,180,30,0.4)");

});