$(function () {

//---------------------------CSS------------------
var redbox=$(".red-box");
	console.log(redbox.css('width'));
	console.log(redbox.width());

	redbox.css("background-color","#AA7700");
	
	$("p").css("font-size","18px");
	
	redbox.css("user-select",function(){
		return "none";
	});

	$("a").addClass("fancy-link");


//-----------------------------------------------
//val
	var textInput= $("input:text")
	textInput.val("Jayant");
	var rangeInput= $("input[type='range']")
	console.log(textInput.val());
	console.log(rangeInput.val());
	
	
	
	//Prop
	/*
	var checkbox=$("input:checkbox");
	console.log(checkbox.prop("checked"));
	*/
	
	
	
	//Attribute
	var mylink= $("#mylink");
	console.log(mylink.attr("href"))
	mylink.attr("href","http://www.google.com");
	console.log(mylink.attr("href"))
	
	//attr(), prop(), val()








//-----------------------------Replace-------------------------------
//$(".red-box, .blue-box, .green-box").empty();

//$("p:first").empty();


//var detachedElement=$("li").detach();
//$("#content").append(detachedElement);



//$("form").children().not("input:text, textarea, br").remove();

//$("li").replaceWith("<li>Replaced List</li>")
//$("<div class='green-box'>New Need!</div>").replaceAll(".red-box, .blue-box");	

//$(".red-box, .blue-box").replaceWith("<div class='green-box'>New Need</div>");
//-----------------------------Addition-------------------------------
//$(".red-box").after($(".red-box"));
//$(".red-box").after($(".blue-box"));


/*
$(".blue-box").before(function(){
	return "<div class='blue-box'>Food</div>"
});
*/

//$(".green-box").before("<div class='green-box'>Food</div>'");
$(".red-box").after("<div class='red-box'>Food</div>'");

$("#content").prepend("<h3>I love India</h3>")
$("#content").append("<h3>I love India</h3>")


//$("<li>2019 World champion</li>").appendTo($("ul ul"));
//$("<li>2019 World champion</li>").prependTo($("ul ul"));

//$("<li>2019 World champion</li>").appendTo($("ul ul:first"));
$("<li>2019 World champion</li>").prependTo($("ul ul:first"));

//$("ul ul:first").prepend("<li>I love India</li>")
//$("ul ul:first").append("<li>I love India</li>")
});